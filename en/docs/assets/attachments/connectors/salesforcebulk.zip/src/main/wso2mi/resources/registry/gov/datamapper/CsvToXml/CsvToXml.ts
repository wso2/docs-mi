import * as dmUtils from "./dm-utils";

/*
* title : "root",
* inputType : "JSON",
*/
interface Root {
    name: string
    description: string
}

/*
* title : "values",
* outputType : "JSON",
*/
interface Values {
    sObject: {
        description: string
        name: string
    }[]
}



/**
 * functionName : map_S_root_S_values
 * inputVariable : inputroot
*/
export function mapFunction(input: Root[]): Values {
    return {
        sObject: input
            .map((inputItem) => {
                return {
                    description: inputItem.description,
                    name: inputItem.name
                }
            })
    }
}

